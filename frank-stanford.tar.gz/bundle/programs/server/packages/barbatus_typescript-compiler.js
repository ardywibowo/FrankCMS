(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var process = Package.modules.process;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;

/* Package-scope variables */
var Logger, TypeScriptCompiler, TypeScript;

var require = meteorInstall({"node_modules":{"meteor":{"barbatus:typescript-compiler":{"logger.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/logger.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _createClass2 = require("babel-runtime/helpers/createClass");                                                     //
                                                                                                                      //
var _createClass3 = _interopRequireDefault(_createClass2);                                                            //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var util = Npm.require('util');                                                                                       // 1
                                                                                                                      //
var Logger_ = function () {                                                                                           //
  function Logger_() {                                                                                                // 4
    (0, _classCallCheck3.default)(this, Logger_);                                                                     // 4
    this.llevel = process.env.TYPESCRIPT_LOG;                                                                         // 5
  }                                                                                                                   // 6
                                                                                                                      //
  Logger_.prototype.newProfiler = function () {                                                                       //
    function newProfiler(name) {                                                                                      //
      var profiler = new Profiler(name);                                                                              // 9
      if (this.isProfile) profiler.start();                                                                           // 10
      return profiler;                                                                                                // 11
    }                                                                                                                 // 12
                                                                                                                      //
    return newProfiler;                                                                                               //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.log = function () {                                                                               //
    function log(msg) {                                                                                               //
      if (this.llevel >= 1) {                                                                                         // 27
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {     // 27
          args[_key - 1] = arguments[_key];                                                                           // 26
        }                                                                                                             // 27
                                                                                                                      //
        console.log.apply(null, [msg].concat(args));                                                                  // 28
      }                                                                                                               // 29
    }                                                                                                                 // 30
                                                                                                                      //
    return log;                                                                                                       //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.debug = function () {                                                                             //
    function debug(msg) {                                                                                             //
      if (this.isDebug) {                                                                                             // 33
        for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];                                                                         // 32
        }                                                                                                             // 33
                                                                                                                      //
        this.log.apply(this, msg, args);                                                                              // 34
      }                                                                                                               // 35
    }                                                                                                                 // 36
                                                                                                                      //
    return debug;                                                                                                     //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.assert = function () {                                                                            //
    function assert(msg) {                                                                                            //
      if (this.isAssert) {                                                                                            // 39
        for (var _len3 = arguments.length, args = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
          args[_key3 - 1] = arguments[_key3];                                                                         // 38
        }                                                                                                             // 39
                                                                                                                      //
        this.log.apply(this, msg, args);                                                                              // 40
      }                                                                                                               // 41
    }                                                                                                                 // 42
                                                                                                                      //
    return assert;                                                                                                    //
  }();                                                                                                                //
                                                                                                                      //
  (0, _createClass3.default)(Logger_, [{                                                                              //
    key: "isDebug",                                                                                                   //
    get: function () {                                                                                                //
      return this.llevel >= 2;                                                                                        // 15
    }                                                                                                                 // 16
  }, {                                                                                                                //
    key: "isProfile",                                                                                                 //
    get: function () {                                                                                                //
      return this.llevel >= 3;                                                                                        // 19
    }                                                                                                                 // 20
  }, {                                                                                                                //
    key: "isAssert",                                                                                                  //
    get: function () {                                                                                                //
      return this.llevel >= 4;                                                                                        // 23
    }                                                                                                                 // 24
  }]);                                                                                                                //
  return Logger_;                                                                                                     //
}();                                                                                                                  //
                                                                                                                      //
;                                                                                                                     // 43
Logger = new Logger_();                                                                                               // 45
                                                                                                                      //
var Profiler = function () {                                                                                          //
  function Profiler(name) {                                                                                           // 48
    (0, _classCallCheck3.default)(this, Profiler);                                                                    // 48
    this.name = name;                                                                                                 // 49
  }                                                                                                                   // 50
                                                                                                                      //
  Profiler.prototype.start = function () {                                                                            //
    function start() {                                                                                                //
      console.log('%s started', this.name);                                                                           // 53
      console.time(util.format('%s time', this.name));                                                                // 54
      this._started = true;                                                                                           // 55
    }                                                                                                                 // 56
                                                                                                                      //
    return start;                                                                                                     //
  }();                                                                                                                //
                                                                                                                      //
  Profiler.prototype.end = function () {                                                                              //
    function end() {                                                                                                  //
      if (this._started) {                                                                                            // 59
        console.timeEnd(util.format('%s time', this.name));                                                           // 60
      }                                                                                                               // 61
    }                                                                                                                 // 62
                                                                                                                      //
    return end;                                                                                                       //
  }();                                                                                                                //
                                                                                                                      //
  return Profiler;                                                                                                    //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"file-utils.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/file-utils.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({                                                                                                       // 1
  isBare: function () {                                                                                               // 1
    return isBare;                                                                                                    // 1
  },                                                                                                                  // 1
  isMainConfig: function () {                                                                                         // 1
    return isMainConfig;                                                                                              // 1
  },                                                                                                                  // 1
  isConfig: function () {                                                                                             // 1
    return isConfig;                                                                                                  // 1
  },                                                                                                                  // 1
  isServerConfig: function () {                                                                                       // 1
    return isServerConfig;                                                                                            // 1
  },                                                                                                                  // 1
  isDeclaration: function () {                                                                                        // 1
    return isDeclaration;                                                                                             // 1
  },                                                                                                                  // 1
  isWeb: function () {                                                                                                // 1
    return isWeb;                                                                                                     // 1
  },                                                                                                                  // 1
  getExtendedPath: function () {                                                                                      // 1
    return getExtendedPath;                                                                                           // 1
  },                                                                                                                  // 1
  getES6ModuleName: function () {                                                                                     // 1
    return getES6ModuleName;                                                                                          // 1
  },                                                                                                                  // 1
  WarnMixin: function () {                                                                                            // 1
    return WarnMixin;                                                                                                 // 1
  },                                                                                                                  // 1
  extendFiles: function () {                                                                                          // 1
    return extendFiles;                                                                                               // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
                                                                                                                      //
var colors = Npm.require('colors');                                                                                   // 1
                                                                                                                      //
function isBare(inputFile) {                                                                                          // 3
  var fileOptions = inputFile.getFileOptions();                                                                       // 4
  return fileOptions && fileOptions.bare;                                                                             // 5
}                                                                                                                     // 6
                                                                                                                      //
function isMainConfig(inputFile) {                                                                                    // 9
  if (!isWeb(inputFile)) return false;                                                                                // 10
  var filePath = inputFile.getPathInPackage();                                                                        // 12
  return (/^tsconfig\.json$/.test(filePath)                                                                           // 13
  );                                                                                                                  // 13
}                                                                                                                     // 14
                                                                                                                      //
function isConfig(inputFile) {                                                                                        // 16
  var filePath = inputFile.getPathInPackage();                                                                        // 17
  return (/tsconfig\.json$/.test(filePath)                                                                            // 18
  );                                                                                                                  // 18
}                                                                                                                     // 19
                                                                                                                      //
function isServerConfig(inputFile) {                                                                                  // 22
  if (isWeb(inputFile)) return false;                                                                                 // 23
  var filePath = inputFile.getPathInPackage();                                                                        // 25
  return (/^server\/tsconfig\.json$/.test(filePath)                                                                   // 26
  );                                                                                                                  // 26
}                                                                                                                     // 27
                                                                                                                      //
function isDeclaration(inputFile) {                                                                                   // 30
  return TypeScript.isDeclarationFile(inputFile.getBasename());                                                       // 31
}                                                                                                                     // 32
                                                                                                                      //
function isWeb(inputFile) {                                                                                           // 34
  var arch = inputFile.getArch();                                                                                     // 35
  return (/^web/.test(arch)                                                                                           // 36
  );                                                                                                                  // 36
}                                                                                                                     // 37
                                                                                                                      //
function getExtendedPath(inputFile) {                                                                                 // 40
  var packageName = inputFile.getPackageName();                                                                       // 41
  packageName = packageName ? packageName.replace(':', '_') + '/' : '';                                               // 42
  var inputFilePath = inputFile.getPathInPackage();                                                                   // 44
  return packageName + inputFilePath;                                                                                 // 45
}                                                                                                                     // 46
                                                                                                                      //
function getES6ModuleName(inputFile) {                                                                                // 48
  var extended = getExtendedPath(inputFile);                                                                          // 49
  return TypeScript.removeTsExt(extended);                                                                            // 50
}                                                                                                                     // 51
                                                                                                                      //
var WarnMixin = {                                                                                                     // 53
  warn: function (error) {                                                                                            // 54
    console.log(error.sourcePath + " (" + error.line + ", " + error.column + "): " + error.message);                  // 55
  },                                                                                                                  // 56
  logError: function (error) {                                                                                        // 57
    console.log(colors.red(error.sourcePath + " (" + error.line + ", " + error.column + "): " + error.message));      // 58
  }                                                                                                                   // 60
};                                                                                                                    // 53
                                                                                                                      //
function extendFiles(inputFiles, fileMixin) {                                                                         // 63
  inputFiles.forEach(function (inputFile) {                                                                           // 64
    return _.defaults(inputFile, fileMixin);                                                                          // 64
  });                                                                                                                 // 64
}                                                                                                                     // 65
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typescript-compiler.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/typescript-compiler.js                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var module1 = module;                                                                                                 // 1
var getExtendedPath = void 0,                                                                                         // 1
    isDeclaration = void 0,                                                                                           // 1
    isConfig = void 0,                                                                                                // 1
    isMainConfig = void 0,                                                                                            // 1
    isServerConfig = void 0,                                                                                          // 1
    isBare = void 0,                                                                                                  // 1
    getES6ModuleName = void 0,                                                                                        // 1
    WarnMixin = void 0,                                                                                               // 1
    extendFiles = void 0,                                                                                             // 1
    isWeb = void 0;                                                                                                   // 1
module1.watch(require("./file-utils"), {                                                                              // 1
  getExtendedPath: function (v) {                                                                                     // 1
    getExtendedPath = v;                                                                                              // 1
  },                                                                                                                  // 1
  isDeclaration: function (v) {                                                                                       // 1
    isDeclaration = v;                                                                                                // 1
  },                                                                                                                  // 1
  isConfig: function (v) {                                                                                            // 1
    isConfig = v;                                                                                                     // 1
  },                                                                                                                  // 1
  isMainConfig: function (v) {                                                                                        // 1
    isMainConfig = v;                                                                                                 // 1
  },                                                                                                                  // 1
  isServerConfig: function (v) {                                                                                      // 1
    isServerConfig = v;                                                                                               // 1
  },                                                                                                                  // 1
  isBare: function (v) {                                                                                              // 1
    isBare = v;                                                                                                       // 1
  },                                                                                                                  // 1
  getES6ModuleName: function (v) {                                                                                    // 1
    getES6ModuleName = v;                                                                                             // 1
  },                                                                                                                  // 1
  WarnMixin: function (v) {                                                                                           // 1
    WarnMixin = v;                                                                                                    // 1
  },                                                                                                                  // 1
  extendFiles: function (v) {                                                                                         // 1
    extendFiles = v;                                                                                                  // 1
  },                                                                                                                  // 1
  isWeb: function (v) {                                                                                               // 1
    isWeb = v;                                                                                                        // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var getShallowHash = void 0;                                                                                          // 1
module1.watch(require("./utils"), {                                                                                   // 1
  getShallowHash: function (v) {                                                                                      // 1
    getShallowHash = v;                                                                                               // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
                                                                                                                      //
var async = Npm.require('async');                                                                                     // 1
                                                                                                                      //
var path = Npm.require('path');                                                                                       // 2
                                                                                                                      //
var fs = Npm.require('fs');                                                                                           // 3
                                                                                                                      //
var Future = Npm.require('fibers/future');                                                                            // 4
                                                                                                                      //
var _Npm$require = Npm.require('meteor-typescript'),                                                                  //
    TSBuild = _Npm$require.TSBuild,                                                                                   //
    validateTsConfig = _Npm$require.validateTsConfig,                                                                 //
    getExcludeRegExp = _Npm$require.getExcludeRegExp;                                                                 //
                                                                                                                      //
var _Npm$require2 = Npm.require('crypto'),                                                                            //
    createHash = _Npm$require2.createHash;                                                                            //
                                                                                                                      //
// Default exclude paths.                                                                                             // 31
var defExclude = new RegExp(getExcludeRegExp(['node_modules/**'])); // What to exclude when compiling for the server.
// typings/main and typings/browser seem to be not used                                                               // 36
// at all but let keep them for just in case.                                                                         // 37
                                                                                                                      //
var exlWebRegExp = new RegExp(getExcludeRegExp(['typings/main/**', 'typings/main.d.ts'])); // What to exclude when compiling for the client.
                                                                                                                      //
var exlMainRegExp = new RegExp(getExcludeRegExp(['typings/browser/**', 'typings/browser.d.ts']));                     // 42
var COMPILER_REGEXP = /(\.d.ts|\.ts|\.tsx|\.tsconfig)$/;                                                              // 45
                                                                                                                      //
TypeScriptCompiler = function () {                                                                                    // 47
  function TypeScriptCompiler(extraOptions, maxParallelism) {                                                         // 48
    (0, _classCallCheck3.default)(this, TypeScriptCompiler);                                                          // 48
    TypeScript.validateExtraOptions(extraOptions);                                                                    // 49
    this.extraOptions = extraOptions;                                                                                 // 51
    this.maxParallelism = maxParallelism || 10;                                                                       // 52
    this.serverOptions = null;                                                                                        // 53
    this.tsconfig = TypeScript.getDefaultOptions();                                                                   // 54
    this.cfgHash = null;                                                                                              // 55
    this.diagHash = new Set();                                                                                        // 56
    this.archSet = new Set();                                                                                         // 57
  }                                                                                                                   // 58
                                                                                                                      //
  TypeScriptCompiler.prototype.getFilesToProcess = function () {                                                      // 47
    function getFilesToProcess(inputFiles) {                                                                          // 47
      var pexclude = Logger.newProfiler('exclude');                                                                   // 61
      inputFiles = this._filterByDefault(inputFiles);                                                                 // 63
                                                                                                                      //
      this._processConfig(inputFiles);                                                                                // 65
                                                                                                                      //
      inputFiles = this._filterByConfig(inputFiles);                                                                  // 67
                                                                                                                      //
      if (inputFiles.length) {                                                                                        // 69
        var arch = inputFiles[0].getArch();                                                                           // 70
        inputFiles = this._filterByArch(inputFiles, arch);                                                            // 71
      }                                                                                                               // 72
                                                                                                                      //
      pexclude.end();                                                                                                 // 74
      return inputFiles;                                                                                              // 76
    }                                                                                                                 // 77
                                                                                                                      //
    return getFilesToProcess;                                                                                         // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype.getBuildOptions = function () {                                                        // 47
    function getBuildOptions(inputFiles) {                                                                            // 47
      this._processConfig(inputFiles);                                                                                // 80
                                                                                                                      //
      var inputFile = inputFiles[0];                                                                                  // 82
      var compilerOptions = this.tsconfig.compilerOptions; // Make a copy.                                            // 79
                                                                                                                      //
      compilerOptions = Object.assign({}, compilerOptions);                                                           // 85
                                                                                                                      //
      if (!isWeb(inputFile) && this.serverOptions) {                                                                  // 86
        Object.assign(compilerOptions, this.serverOptions);                                                           // 87
      } // Apply extra options.                                                                                       // 88
                                                                                                                      //
                                                                                                                      //
      if (this.extraOptions) {                                                                                        // 91
        Object.assign(compilerOptions, this.extraOptions);                                                            // 92
      }                                                                                                               // 93
                                                                                                                      //
      var arch = inputFile.getArch();                                                                                 // 95
      var _tsconfig = this.tsconfig,                                                                                  // 79
          typings = _tsconfig.typings,                                                                                // 79
          useCache = _tsconfig.useCache;                                                                              // 79
      return {                                                                                                        // 97
        arch: arch,                                                                                                   // 97
        compilerOptions: compilerOptions,                                                                             // 97
        typings: typings,                                                                                             // 97
        useCache: useCache                                                                                            // 97
      };                                                                                                              // 97
    }                                                                                                                 // 98
                                                                                                                      //
    return getBuildOptions;                                                                                           // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype.processFilesForTarget = function () {                                                  // 47
    function processFilesForTarget(inputFiles, getDepsContent) {                                                      // 47
      var _this = this;                                                                                               // 100
                                                                                                                      //
      extendFiles(inputFiles, WarnMixin);                                                                             // 101
      var options = this.getBuildOptions(inputFiles);                                                                 // 103
      Logger.log('compiler options: %j', options.compilerOptions);                                                    // 104
      inputFiles = this.getFilesToProcess(inputFiles);                                                                // 106
      if (!inputFiles.length) return;                                                                                 // 108
      var pcompile = Logger.newProfiler('compilation');                                                               // 110
      var filePaths = inputFiles.map(function (file) {                                                                // 111
        return getExtendedPath(file);                                                                                 // 111
      });                                                                                                             // 111
      Logger.log('compile files: %s', filePaths);                                                                     // 112
      var pbuild = Logger.newProfiler('tsBuild');                                                                     // 114
                                                                                                                      //
      var defaultGet = this._getContentGetter(inputFiles);                                                            // 115
                                                                                                                      //
      var getContent = function (filePath) {                                                                          // 116
        return getDepsContent && getDepsContent(filePath) || defaultGet(filePath);                                    // 116
      };                                                                                                              // 116
                                                                                                                      //
      var tsBuild = new TSBuild(filePaths, getContent, options);                                                      // 118
      pbuild.end();                                                                                                   // 119
      var pfiles = Logger.newProfiler('tsEmitFiles');                                                                 // 121
      var future = new Future(); // Don't emit typings.                                                               // 122
                                                                                                                      //
      var compileFiles = inputFiles.filter(function (file) {                                                          // 124
        return !isDeclaration(file);                                                                                  // 124
      });                                                                                                             // 124
      var throwSyntax = false;                                                                                        // 125
      var results = new Map();                                                                                        // 126
      async.eachLimit(compileFiles, this.maxParallelism, function (file, done) {                                      // 127
        var co = options.compilerOptions;                                                                             // 128
        var filePath = getExtendedPath(file); // Module set none explicitly, don't use ES6 modules.                   // 130
                                                                                                                      //
        var moduleName = co.module === 'none' ? null : getES6ModuleName(file);                                        // 132
        var pemit = Logger.newProfiler('tsEmit');                                                                     // 134
        var result = tsBuild.emit(filePath, moduleName);                                                              // 135
        results.set(file, result);                                                                                    // 136
        pemit.end();                                                                                                  // 137
        throwSyntax = throwSyntax | _this._processDiagnostics(file, result.diagnostics, co);                          // 139
        done();                                                                                                       // 142
      }, future.resolver());                                                                                          // 143
      pfiles.end();                                                                                                   // 145
      future.wait();                                                                                                  // 147
                                                                                                                      //
      if (!throwSyntax) {                                                                                             // 149
        results.forEach(function (result, file) {                                                                     // 150
          var module = options.compilerOptions.module;                                                                // 151
                                                                                                                      //
          _this._addJavaScript(file, result, module === 'none');                                                      // 152
        });                                                                                                           // 153
      }                                                                                                               // 154
                                                                                                                      //
      pcompile.end();                                                                                                 // 156
    }                                                                                                                 // 157
                                                                                                                      //
    return processFilesForTarget;                                                                                     // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._getContentGetter = function () {                                                      // 47
    function _getContentGetter(inputFiles) {                                                                          // 47
      var filesMap = new Map();                                                                                       // 160
      inputFiles.forEach(function (inputFile, index) {                                                                // 161
        filesMap.set(getExtendedPath(inputFile), index);                                                              // 162
      });                                                                                                             // 163
      return function (filePath) {                                                                                    // 165
        var index = filesMap.get(filePath);                                                                           // 166
                                                                                                                      //
        if (index === undefined) {                                                                                    // 167
          var filePathNoRootSlash = filePath.replace(/^\//, '');                                                      // 168
          index = filesMap.get(filePathNoRootSlash);                                                                  // 169
        }                                                                                                             // 170
                                                                                                                      //
        return index !== undefined ? inputFiles[index].getContentsAsString() : null;                                  // 171
      };                                                                                                              // 173
    }                                                                                                                 // 174
                                                                                                                      //
    return _getContentGetter;                                                                                         // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._addJavaScript = function () {                                                         // 47
    function _addJavaScript(inputFile, tsResult, forceBare) {                                                         // 47
      var source = inputFile.getContentsAsString();                                                                   // 177
      var inputPath = inputFile.getPathInPackage();                                                                   // 178
      var outputPath = TypeScript.removeTsExt(inputPath) + '.js';                                                     // 179
      var toBeAdded = {                                                                                               // 180
        sourcePath: inputPath,                                                                                        // 181
        path: outputPath,                                                                                             // 182
        data: tsResult.code,                                                                                          // 183
        hash: tsResult.hash,                                                                                          // 184
        sourceMap: tsResult.sourceMap,                                                                                // 185
        bare: forceBare || isBare(inputFile)                                                                          // 186
      };                                                                                                              // 180
      inputFile.addJavaScript(toBeAdded);                                                                             // 188
    }                                                                                                                 // 189
                                                                                                                      //
    return _addJavaScript;                                                                                            // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._processDiagnostics = function () {                                                    // 47
    function _processDiagnostics(inputFile, diagnostics, tsOptions) {                                                 // 47
      var _this2 = this;                                                                                              // 191
                                                                                                                      //
      // Remove duplicated warnings for shared files                                                                  // 192
      // by saving hashes of already shown warnings.                                                                  // 193
      var reduce = function (diagnostic, cb) {                                                                        // 194
        var dob = {                                                                                                   // 195
          message: diagnostic.message,                                                                                // 196
          sourcePath: getExtendedPath(inputFile),                                                                     // 197
          line: diagnostic.line,                                                                                      // 198
          column: diagnostic.column                                                                                   // 199
        };                                                                                                            // 195
        var arch = inputFile.getArch(); // TODO: find out how to get list of architectures.                           // 201
                                                                                                                      //
        _this2.archSet.add(arch);                                                                                     // 203
                                                                                                                      //
        var shown = false;                                                                                            // 205
                                                                                                                      //
        for (var _iterator = _this2.archSet.keys(), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
          var _ref;                                                                                                   // 206
                                                                                                                      //
          if (_isArray) {                                                                                             // 206
            if (_i >= _iterator.length) break;                                                                        // 206
            _ref = _iterator[_i++];                                                                                   // 206
          } else {                                                                                                    // 206
            _i = _iterator.next();                                                                                    // 206
            if (_i.done) break;                                                                                       // 206
            _ref = _i.value;                                                                                          // 206
          }                                                                                                           // 206
                                                                                                                      //
          var key = _ref;                                                                                             // 206
                                                                                                                      //
          if (key !== arch) {                                                                                         // 207
            dob.arch = key;                                                                                           // 208
                                                                                                                      //
            var _hash = getShallowHash(dob);                                                                          // 209
                                                                                                                      //
            if (_this2.diagHash.has(_hash)) {                                                                         // 210
              shown = true;                                                                                           // 211
              break;                                                                                                  // 211
            }                                                                                                         // 212
          }                                                                                                           // 213
        }                                                                                                             // 214
                                                                                                                      //
        if (!shown) {                                                                                                 // 216
          dob.arch = arch;                                                                                            // 217
          var hash = getShallowHash(dob);                                                                             // 218
                                                                                                                      //
          _this2.diagHash.add(hash);                                                                                  // 219
                                                                                                                      //
          cb(dob);                                                                                                    // 220
        }                                                                                                             // 221
      }; // Always throw syntax errors.                                                                               // 222
                                                                                                                      //
                                                                                                                      //
      var throwSyntax = !!diagnostics.syntacticErrors.length;                                                         // 225
      diagnostics.syntacticErrors.forEach(function (diagnostic) {                                                     // 226
        reduce(diagnostic, function (dob) {                                                                           // 227
          inputFile.error(dob);                                                                                       // 228
        });                                                                                                           // 229
      });                                                                                                             // 230
      var packageName = inputFile.getPackageName();                                                                   // 232
      if (packageName) return throwSyntax; // And log out other errors except package files.                          // 233
                                                                                                                      //
      if (tsOptions && tsOptions.diagnostics) {                                                                       // 236
        diagnostics.semanticErrors.forEach(function (diagnostic) {                                                    // 237
          reduce(diagnostic, function (dob) {                                                                         // 238
            return inputFile.warn(dob);                                                                               // 238
          });                                                                                                         // 238
        });                                                                                                           // 239
      }                                                                                                               // 240
                                                                                                                      //
      return throwSyntax;                                                                                             // 242
    }                                                                                                                 // 243
                                                                                                                      //
    return _processDiagnostics;                                                                                       // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._getFileModuleName = function () {                                                     // 47
    function _getFileModuleName(inputFile, options) {                                                                 // 47
      if (options.module === 'none') return null;                                                                     // 246
      return getES6ModuleName(inputFile);                                                                             // 248
    }                                                                                                                 // 249
                                                                                                                      //
    return _getFileModuleName;                                                                                        // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._processConfig = function () {                                                         // 47
    function _processConfig(inputFiles) {                                                                             // 47
      for (var _iterator2 = inputFiles, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
        var _ref2;                                                                                                    // 252
                                                                                                                      //
        if (_isArray2) {                                                                                              // 252
          if (_i2 >= _iterator2.length) break;                                                                        // 252
          _ref2 = _iterator2[_i2++];                                                                                  // 252
        } else {                                                                                                      // 252
          _i2 = _iterator2.next();                                                                                    // 252
          if (_i2.done) break;                                                                                        // 252
          _ref2 = _i2.value;                                                                                          // 252
        }                                                                                                             // 252
                                                                                                                      //
        var inputFile = _ref2;                                                                                        // 252
                                                                                                                      //
        // Parse root config.                                                                                         // 253
        if (isMainConfig(inputFile)) {                                                                                // 254
          var source = inputFile.getContentsAsString();                                                               // 255
          var hash = inputFile.getSourceHash(); // If hashes differ, create new tsconfig.                             // 256
                                                                                                                      //
          if (hash !== this.cfgHash) {                                                                                // 258
            this.tsconfig = this._parseConfig(source);                                                                // 259
            this.cfgHash = hash;                                                                                      // 260
          }                                                                                                           // 261
        } // Parse server config.                                                                                     // 262
        // Take only target and lib values.                                                                           // 265
                                                                                                                      //
                                                                                                                      //
        if (isServerConfig(inputFile)) {                                                                              // 266
          var _source = inputFile.getContentsAsString();                                                              // 267
                                                                                                                      //
          var _parseConfig2 = this._parseConfig(_source),                                                             // 266
              compilerOptions = _parseConfig2.compilerOptions;                                                        // 266
                                                                                                                      //
          if (compilerOptions) {                                                                                      // 269
            var target = compilerOptions.target,                                                                      // 269
                lib = compilerOptions.lib;                                                                            // 269
            this.serverOptions = {                                                                                    // 271
              target: target,                                                                                         // 271
              lib: lib                                                                                                // 271
            };                                                                                                        // 271
          }                                                                                                           // 272
        }                                                                                                             // 273
      }                                                                                                               // 274
    }                                                                                                                 // 275
                                                                                                                      //
    return _processConfig;                                                                                            // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._parseConfig = function () {                                                           // 47
    function _parseConfig(cfgContent) {                                                                               // 47
      var tsconfig = null;                                                                                            // 278
                                                                                                                      //
      try {                                                                                                           // 280
        tsconfig = JSON.parse(cfgContent);                                                                            // 281
        validateTsConfig(tsconfig);                                                                                   // 283
      } catch (err) {                                                                                                 // 284
        throw new Error("Format of the tsconfig is invalid: " + err);                                                 // 285
      }                                                                                                               // 286
                                                                                                                      //
      var exclude = tsconfig.exclude || [];                                                                           // 288
                                                                                                                      //
      try {                                                                                                           // 289
        var regExp = getExcludeRegExp(exclude);                                                                       // 290
        tsconfig.exclude = regExp && new RegExp(regExp);                                                              // 291
      } catch (err) {                                                                                                 // 292
        throw new Error("Format of an exclude path is invalid: " + err);                                              // 293
      }                                                                                                               // 294
                                                                                                                      //
      return tsconfig;                                                                                                // 296
    }                                                                                                                 // 297
                                                                                                                      //
    return _parseConfig;                                                                                              // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._filterByDefault = function () {                                                       // 47
    function _filterByDefault(inputFiles) {                                                                           // 47
      inputFiles = inputFiles.filter(function (inputFile) {                                                           // 300
        var path = inputFile.getPathInPackage();                                                                      // 301
        return COMPILER_REGEXP.test(path) && !defExclude.test('/' + path);                                            // 302
      });                                                                                                             // 303
      return inputFiles;                                                                                              // 304
    }                                                                                                                 // 305
                                                                                                                      //
    return _filterByDefault;                                                                                          // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._filterByConfig = function () {                                                        // 47
    function _filterByConfig(inputFiles) {                                                                            // 47
      var _this3 = this;                                                                                              // 307
                                                                                                                      //
      var resultFiles = inputFiles;                                                                                   // 308
                                                                                                                      //
      if (this.tsconfig.exclude) {                                                                                    // 309
        resultFiles = resultFiles.filter(function (inputFile) {                                                       // 310
          var path = inputFile.getPathInPackage(); // There seems to an issue with getRegularExpressionForWildcard:   // 311
          // result regexp always starts with /.                                                                      // 313
                                                                                                                      //
          return !_this3.tsconfig.exclude.test('/' + path);                                                           // 314
        });                                                                                                           // 315
      }                                                                                                               // 316
                                                                                                                      //
      return resultFiles;                                                                                             // 317
    }                                                                                                                 // 318
                                                                                                                      //
    return _filterByConfig;                                                                                           // 47
  }();                                                                                                                // 47
                                                                                                                      //
  TypeScriptCompiler.prototype._filterByArch = function () {                                                          // 47
    function _filterByArch(inputFiles, arch) {                                                                        // 47
      check(arch, String); /**                                                                                        // 321
                            * Include only typings that current arch needs,                                           //
                            * typings/main is for the server only and                                                 //
                            * typings/browser - for the client.                                                       //
                            */                                                                                        //
      var filterRegExp = /^web/.test(arch) ? exlWebRegExp : exlMainRegExp;                                            // 328
      inputFiles = inputFiles.filter(function (inputFile) {                                                           // 329
        var path = inputFile.getPathInPackage();                                                                      // 330
        return !filterRegExp.test('/' + path);                                                                        // 331
      });                                                                                                             // 332
      return inputFiles;                                                                                              // 334
    }                                                                                                                 // 335
                                                                                                                      //
    return _filterByArch;                                                                                             // 47
  }();                                                                                                                // 47
                                                                                                                      //
  return TypeScriptCompiler;                                                                                          // 47
}();                                                                                                                  // 47
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typescript.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/typescript.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var meteorTS = Npm.require('meteor-typescript');                                                                      // 1
                                                                                                                      //
TypeScript = {                                                                                                        // 3
  validateOptions: function (options) {                                                                               // 4
    if (!options) return;                                                                                             // 5
    meteorTS.validateAndConvertOptions(options);                                                                      // 7
  },                                                                                                                  // 8
  // Extra options are the same compiler options                                                                      // 10
  // but passed in the compiler constructor.                                                                          // 11
  validateExtraOptions: function (options) {                                                                          // 12
    if (!options) return;                                                                                             // 13
    meteorTS.validateAndConvertOptions({                                                                              // 15
      compilerOptions: options                                                                                        // 16
    });                                                                                                               // 15
  },                                                                                                                  // 18
  getDefaultOptions: meteorTS.getDefaultOptions,                                                                      // 20
  compile: function (source, options) {                                                                               // 22
    options = options || meteorTS.getDefaultOptions();                                                                // 23
    return meteorTS.compile(source, options);                                                                         // 24
  },                                                                                                                  // 25
  setCacheDir: function (cacheDir) {                                                                                  // 27
    meteorTS.setCacheDir(cacheDir);                                                                                   // 28
  },                                                                                                                  // 29
  isDeclarationFile: function (filePath) {                                                                            // 31
    return (/^.*\.d\.ts$/.test(filePath)                                                                              // 32
    );                                                                                                                // 32
  },                                                                                                                  // 33
  removeTsExt: function (path) {                                                                                      // 35
    return path && path.replace(/(\.tsx|\.ts)$/g, '');                                                                // 36
  }                                                                                                                   // 37
};                                                                                                                    // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/utils.js                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({                                                                                                       // 1
  getShallowHash: function () {                                                                                       // 1
    return getShallowHash;                                                                                            // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
                                                                                                                      //
var _Npm$require = Npm.require('crypto'),                                                                             //
    createHash = _Npm$require.createHash;                                                                             //
                                                                                                                      //
function getShallowHash(ob) {                                                                                         // 3
  var hash = createHash('sha1');                                                                                      // 4
  var keys = Object.keys(ob);                                                                                         // 5
  keys.sort();                                                                                                        // 6
  keys.forEach(function (key) {                                                                                       // 8
    hash.update(key).update('' + ob[key]);                                                                            // 9
  });                                                                                                                 // 10
  return hash.digest('hex');                                                                                          // 12
}                                                                                                                     // 13
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./node_modules/meteor/barbatus:typescript-compiler/logger.js");
require("./node_modules/meteor/barbatus:typescript-compiler/file-utils.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript-compiler.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript.js");
require("./node_modules/meteor/barbatus:typescript-compiler/utils.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['barbatus:typescript-compiler'] = {}, {
  TypeScript: TypeScript,
  TypeScriptCompiler: TypeScriptCompiler
});

})();

//# sourceMappingURL=barbatus_typescript-compiler.js.map
