var require = meteorInstall({"server":{"imports":{"publications":{"album.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// server/imports/publications/album.js                                               //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_1 = require("meteor/meteor");                                              // 1
var tmeasday_publish_counts_1 = require("meteor/tmeasday:publish-counts");            // 2
var albums_collection_1 = require("../../../both/collections/albums.collection");     // 4
meteor_1.Meteor.publish('albums', function (options, name) {                          // 10
    var selector = buildQuery.call(this, null, name);                                 //
    tmeasday_publish_counts_1.Counts.publish(this, 'numberOfAlbums', albums_collection_1.Albums.collection.find(selector), { noReady: true });
    return albums_collection_1.Albums.find(selector, options);                        //
});                                                                                   // 16
meteor_1.Meteor.publish('album', function (albumId) {                                 // 18
    return albums_collection_1.Albums.find(buildQuery.call(this, albumId));           //
});                                                                                   // 20
function buildQuery(albumId, name) {                                                  // 22
    var isAvailable = {                                                               //
        $or: [{ private: false }, { private: (this.userId != null) }]                 //
    };                                                                                //
    if (albumId) {                                                                    //
        return {                                                                      //
            // only single album                                                      //
            $and: [{                                                                  //
                    _id: albumId                                                      //
                },                                                                    //
                isAvailable                                                           //
            ]                                                                         //
        };                                                                            //
    }                                                                                 //
    var searchRegEx = { '$regex': '.*' + (name || '') + '.*', '$options': 'i' };      //
    return {                                                                          //
        $and: [{                                                                      //
                'name': searchRegEx                                                   //
            },                                                                        //
            isAvailable                                                               //
        ]                                                                             //
    };                                                                                //
}                                                                                     // 47
////////////////////////////////////////////////////////////////////////////////////////

},"artworks.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// server/imports/publications/artworks.js                                            //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_1 = require("meteor/meteor");                                              // 1
var tmeasday_publish_counts_1 = require("meteor/tmeasday:publish-counts");            // 2
var artworks_collection_1 = require("../../../both/collections/artworks.collection");
meteor_1.Meteor.publish('artworks', function (options, name, inputSelector) {         // 10
    var selector = buildQuery.call(this, null, name);                                 //
    var isAvailable = {                                                               //
        $or: [{ private: false }, { private: (this.userId != null) }]                 //
    };                                                                                //
    inputSelector = {                                                                 //
        $and: [inputSelector, isAvailable]                                            //
    };                                                                                //
    tmeasday_publish_counts_1.Counts.publish(this, 'numberOfArtworks', artworks_collection_1.Artworks.collection.find(inputSelector), { noReady: true });
    return artworks_collection_1.Artworks.find(selector, options);                    //
});                                                                                   // 23
meteor_1.Meteor.publish('artwork', function (artworkId) {                             // 25
    return artworks_collection_1.Artworks.find(buildQuery.call(this, artworkId));     //
});                                                                                   // 27
function buildQuery(artworkId, name) {                                                // 29
    var isAvailable = {                                                               //
        $or: [{ private: false }, { private: (this.userId != null) }]                 //
    };                                                                                //
    if (artworkId) {                                                                  //
        return {                                                                      //
            // only single album                                                      //
            $and: [{                                                                  //
                    _id: artworkId                                                    //
                },                                                                    //
                isAvailable                                                           //
            ]                                                                         //
        };                                                                            //
    }                                                                                 //
    var searchRegEx = { '$regex': '.*' + (name || '') + '.*', '$options': 'i' };      //
    return {                                                                          //
        $and: [{                                                                      //
                'name': searchRegEx                                                   //
            },                                                                        //
            isAvailable                                                               //
        ]                                                                             //
    };                                                                                //
}                                                                                     // 54
////////////////////////////////////////////////////////////////////////////////////////

},"exposes.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// server/imports/publications/exposes.js                                             //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_1 = require("meteor/meteor");                                              // 1
var exposes_collection_1 = require("../../../both/collections/exposes.collection");   // 3
meteor_1.Meteor.publish('exposes', function () {                                      // 5
    return exposes_collection_1.Exposes.collection.find();                            //
});                                                                                   // 7
////////////////////////////////////////////////////////////////////////////////////////

},"files.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// server/imports/publications/files.js                                               //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_1 = require("meteor/meteor");                                              // 1
var files_collection_1 = require("../../../both/collections/files.collection");       // 2
meteor_1.Meteor.publish('files', function () {                                        // 4
    return files_collection_1.Files.collection.find({});                              //
});                                                                                   // 6
////////////////////////////////////////////////////////////////////////////////////////

},"images.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// server/imports/publications/images.js                                              //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_1 = require("meteor/meteor");                                              // 1
var images_collection_1 = require("../../../both/collections/images.collection");     // 2
meteor_1.Meteor.publish('thumbs', function (ids) {                                    // 4
    return images_collection_1.Thumbs.collection.find({                               //
        originalStore: 'images',                                                      //
        originalId: {                                                                 //
            $in: ids                                                                  //
        }                                                                             //
    });                                                                               //
});                                                                                   // 11
meteor_1.Meteor.publish('images', function () {                                       // 13
    return images_collection_1.Images.collection.find({});                            //
});                                                                                   // 15
////////////////////////////////////////////////////////////////////////////////////////

}}},"main.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// server/main.js                                                                     //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_1 = require("meteor/meteor");                                              // 1
var random_1 = require("meteor/random");                                              // 3
var accounts_base_1 = require("meteor/accounts-base");                                // 4
require("./imports/publications/artworks");                                           // 6
require("./imports/publications/images");                                             // 7
require("./imports/publications/album");                                              // 8
require("./imports/publications/files");                                              // 9
require("./imports/publications/exposes");                                            // 10
meteor_1.Meteor.startup(function () {                                                 // 12
    process.env.MAIL_URL = 'smtp://postmaster%40sandbox8614cb880bbc4c6480976550a1329fae.mailgun.org:22e22763c4ef9f5c4feb66c33bc222bd@smtp.mailgun.org:587';
    accounts_base_1.Accounts.urls.resetPassword = function (token) {                  //
        return meteor_1.Meteor.absoluteUrl('reset-password/' + token);                //
    };                                                                                //
    if (meteor_1.Meteor.users.find({}).count() < 1) {                                 //
        // Create user account                                                        //
        var loginEmail = 'frankstanford@yahoo.com';                                   //
        var tempPassword = random_1.Random.secret();                                  //
        accounts_base_1.Accounts.createUser({                                         //
            email: loginEmail,                                                        //
            password: tempPassword                                                    //
        });                                                                           //
    }                                                                                 //
});                                                                                   // 29
////////////////////////////////////////////////////////////////////////////////////////

}},"both":{"collections":{"albums.collection.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/collections/albums.collection.js                                              //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_rxjs_1 = require("meteor-rxjs");                                           // 1
var meteor_1 = require("meteor/meteor");                                              // 2
exports.Albums = new meteor_rxjs_1.MongoObservable.Collection('albums');              // 6
function loggedIn() {                                                                 // 8
    // return true;                                                                   //
    return !!meteor_1.Meteor.user();                                                  //
}                                                                                     // 11
exports.Albums.allow({                                                                // 13
    insert: loggedIn,                                                                 //
    update: loggedIn,                                                                 //
    remove: loggedIn                                                                  //
});                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////

},"artworks.collection.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/collections/artworks.collection.js                                            //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_rxjs_1 = require("meteor-rxjs");                                           // 1
var meteor_1 = require("meteor/meteor");                                              // 2
exports.Artworks = new meteor_rxjs_1.MongoObservable.Collection('artworks');          // 6
function loggedIn() {                                                                 // 8
    // return true;                                                                   //
    return !!meteor_1.Meteor.user();                                                  //
}                                                                                     // 11
exports.Artworks.allow({                                                              // 13
    insert: loggedIn,                                                                 //
    update: loggedIn,                                                                 //
    remove: loggedIn                                                                  //
});                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////

},"exposes.collection.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/collections/exposes.collection.js                                             //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_rxjs_1 = require("meteor-rxjs");                                           // 1
var meteor_1 = require("meteor/meteor");                                              // 2
exports.Exposes = new meteor_rxjs_1.MongoObservable.Collection('exposes');            // 6
function loggedIn() {                                                                 // 8
    // return true;                                                                   //
    return !!meteor_1.Meteor.user();                                                  //
}                                                                                     // 11
exports.Exposes.allow({                                                               // 13
    insert: loggedIn,                                                                 //
    update: loggedIn,                                                                 //
    remove: loggedIn                                                                  //
});                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////

},"files.collection.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/collections/files.collection.js                                               //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_rxjs_1 = require("meteor-rxjs");                                           // 1
var meteor_1 = require("meteor/meteor");                                              // 2
var jalik_ufs_1 = require("meteor/jalik:ufs");                                        // 3
exports.Files = new meteor_rxjs_1.MongoObservable.Collection('files');                // 6
function loggedIn() {                                                                 // 8
    // return true;                                                                   //
    return !!meteor_1.Meteor.user();                                                  //
}                                                                                     // 11
exports.FilesStore = new jalik_ufs_1.UploadFS.store.GridFS({                          // 13
    collection: exports.Files.collection,                                             //
    name: 'files',                                                                    //
    permissions: new jalik_ufs_1.UploadFS.StorePermissions({                          //
        insert: loggedIn,                                                             //
        update: loggedIn,                                                             //
        remove: loggedIn                                                              //
    })                                                                                //
});                                                                                   //
exports.Files.allow({                                                                 // 23
    insert: loggedIn,                                                                 //
    update: loggedIn,                                                                 //
    remove: loggedIn                                                                  //
});                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////

},"images.collection.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/collections/images.collection.js                                              //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_rxjs_1 = require("meteor-rxjs");                                           // 1
var meteor_1 = require("meteor/meteor");                                              // 2
var jalik_ufs_1 = require("meteor/jalik:ufs");                                        // 3
exports.Images = new meteor_rxjs_1.MongoObservable.Collection('images');              // 6
exports.Thumbs = new meteor_rxjs_1.MongoObservable.Collection('thumbs');              // 7
function loggedIn() {                                                                 // 9
    // return true;                                                                   //
    return !!meteor_1.Meteor.user();                                                  //
}                                                                                     // 12
exports.ThumbsStore = new jalik_ufs_1.UploadFS.store.GridFS({                         // 14
    collection: exports.Thumbs.collection,                                            //
    name: 'thumbs',                                                                   //
    permissions: new jalik_ufs_1.UploadFS.StorePermissions({                          //
        insert: loggedIn,                                                             //
        update: loggedIn,                                                             //
        remove: loggedIn                                                              //
    }),                                                                               //
    transformWrite: function (from, to, fileId, file) {                               //
        var gm = Npm.require('gm');                                                   //
        if (gm) {                                                                     //
            gm(from)                                                                  //
                .resize(100, 100)                                                     //
                .gravity('Center')                                                    //
                .extent(100, 100)                                                     //
                .quality(80)                                                          //
                .stream().pipe(to);                                                   //
        }                                                                             //
        else {                                                                        //
            console.error("gm is not available", file);                               //
        }                                                                             //
    }                                                                                 //
});                                                                                   //
exports.ImagesStore = new jalik_ufs_1.UploadFS.store.GridFS({                         // 37
    collection: exports.Images.collection,                                            //
    name: 'images',                                                                   //
    filter: new jalik_ufs_1.UploadFS.Filter({                                         //
        contentTypes: ['image/*']                                                     //
    }),                                                                               //
    copyTo: [                                                                         //
        exports.ThumbsStore                                                           //
    ],                                                                                //
    permissions: new jalik_ufs_1.UploadFS.StorePermissions({                          //
        insert: loggedIn,                                                             //
        update: loggedIn,                                                             //
        remove: loggedIn                                                              //
    })                                                                                //
});                                                                                   //
exports.Images.allow({                                                                // 53
    insert: loggedIn,                                                                 //
    update: loggedIn,                                                                 //
    remove: loggedIn                                                                  //
});                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////

},"users.collection.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/collections/users.collection.js                                               //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var meteor_rxjs_1 = require("meteor-rxjs");                                           // 1
var meteor_1 = require("meteor/meteor");                                              // 2
exports.Users = meteor_rxjs_1.MongoObservable.fromExisting(meteor_1.Meteor.users);    // 4
////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"files.methods.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/methods/files.methods.js                                                      //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var jalik_ufs_1 = require("meteor/jalik:ufs");                                        // 1
var files_collection_1 = require("/both/collections/files.collection");               // 2
function upload(data) {                                                               // 4
    return new Promise(function (resolve, reject) {                                   //
        // pick from an object only: name, type and size                              //
        var file = {                                                                  //
            name: data.name,                                                          //
            type: data.type,                                                          //
            size: data.size,                                                          //
        };                                                                            //
        var upload = new jalik_ufs_1.UploadFS.Uploader({                              //
            data: data,                                                               //
            file: file,                                                               //
            store: files_collection_1.FilesStore,                                     //
            onError: reject,                                                          //
            onComplete: resolve                                                       //
        });                                                                           //
        upload.start();                                                               //
    });                                                                               //
}                                                                                     // 23
exports.upload = upload;                                                              // 4
////////////////////////////////////////////////////////////////////////////////////////

},"images.methods.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/methods/images.methods.js                                                     //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var jalik_ufs_1 = require("meteor/jalik:ufs");                                        // 1
var images_collection_1 = require("/both/collections/images.collection");             // 2
function upload(data) {                                                               // 4
    return new Promise(function (resolve, reject) {                                   //
        // pick from an object only: name, type and size                              //
        var file = {                                                                  //
            name: data.name,                                                          //
            type: data.type,                                                          //
            size: data.size,                                                          //
        };                                                                            //
        var upload = new jalik_ufs_1.UploadFS.Uploader({                              //
            data: data,                                                               //
            file: file,                                                               //
            store: images_collection_1.ImagesStore,                                   //
            onError: reject,                                                          //
            onComplete: resolve                                                       //
        });                                                                           //
        upload.start();                                                               //
    });                                                                               //
}                                                                                     // 23
exports.upload = upload;                                                              // 4
////////////////////////////////////////////////////////////////////////////////////////

}},"models":{"album.model.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/models/album.model.js                                                         //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
////////////////////////////////////////////////////////////////////////////////////////

},"artwork.model.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/models/artwork.model.js                                                       //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
var Category;                                                                         // 4
(function (Category) {                                                                // 4
    Category[Category["Photography"] = 0] = "Photography";                            //
    Category[Category["Sculpture"] = 1] = "Sculpture";                                //
    Category[Category["Travels"] = 2] = "Travels";                                    //
    Category[Category["Writing"] = 3] = "Writing";                                    //
    Category[Category["Any"] = 4] = "Any";                                            //
})(Category = exports.Category || (exports.Category = {}));                           // 10
////////////////////////////////////////////////////////////////////////////////////////

},"collection-object.model.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/models/collection-object.model.js                                             //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
////////////////////////////////////////////////////////////////////////////////////////

},"expose.model.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/models/expose.model.js                                                        //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
////////////////////////////////////////////////////////////////////////////////////////

},"file.model.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/models/file.model.js                                                          //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
////////////////////////////////////////////////////////////////////////////////////////

},"image.model.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// both/models/image.model.js                                                         //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Object.defineProperty(exports, "__esModule", { value: true });                        //
////////////////////////////////////////////////////////////////////////////////////////

}}},"deploy":{"mup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// deploy/mup.js                                                                      //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
module.exports = {                                                                    // 1
  servers: {                                                                          // 2
    one: {                                                                            // 3
      host: 'frankstanford.com',                                                      // 4
      username: 'randy',                                                              // 5
      pem: "../keys/digitalocean",                                                    // 6
      opts: {                                                                         // 7
        port: 22                                                                      // 8
      }                                                                               // 7
    }                                                                                 // 3
  },                                                                                  // 2
  meteor: {                                                                           // 13
    name: 'frank-stanford',                                                           // 14
    path: '../',                                                                      // 15
    servers: {                                                                        // 16
      one: {}                                                                         // 17
    },                                                                                // 16
    buildOptions: {                                                                   // 19
      serverOnly: true                                                                // 20
    },                                                                                // 19
    env: {                                                                            // 22
      PORT: 3000,                                                                     // 23
      ROOT_URL: 'http://frankstanford.com',                                           // 24
      MONGO_URL: 'mongodb://127.0.0.1:27017/meteor'                                   // 25
    },                                                                                // 22
    dockerImage: 'abernix/meteord:base',                                              // 28
    deployCheckWaitTime: 240                                                          // 29
  },                                                                                  // 13
  mongo: {                                                                            // 32
    oplog: true,                                                                      // 33
    port: 27017,                                                                      // 34
    servers: {                                                                        // 35
      one: {}                                                                         // 36
    }                                                                                 // 35
  }                                                                                   // 32
};                                                                                    // 1
////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".html",
    ".scss",
    ".less"
  ]
});
require("./both/collections/albums.collection.js");
require("./both/collections/artworks.collection.js");
require("./both/collections/exposes.collection.js");
require("./both/collections/files.collection.js");
require("./both/collections/images.collection.js");
require("./both/collections/users.collection.js");
require("./both/methods/files.methods.js");
require("./both/methods/images.methods.js");
require("./both/models/album.model.js");
require("./both/models/artwork.model.js");
require("./both/models/collection-object.model.js");
require("./both/models/expose.model.js");
require("./both/models/file.model.js");
require("./both/models/image.model.js");
require("./deploy/mup.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
